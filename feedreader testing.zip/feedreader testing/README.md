# Project Overview

This project is a web application that reads RSS feeds. This project uses the `jasmine`plugin. There are 4 suites and required for the project.

## Importance of the Project

Testing is very important for development process and many organisations do a practice of test-driven development. In this organisation the developers first write tests before developing the web application. They then write the code to pass all these tests.

## What I had learned from the project
I had learned how to use jasmine in passing out the various tests. This also will test the event handling and DOM manipulation.

I had completed this project by taking the help of already written test for one of specs and also learnt the usage of jasmine in the course lessons.